/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testtransportpublicconsol;


/**
 *
 * @author ZEED
 */
public class TestTransportPublicConsol {

    public static void main(String[] args) {
       /* IMapperManager mapperManager = new DbMapperManager(
                DataSourceFactory.getMysqlSQLDataSource("localhost",
                        3306, "company", "root", "Google2018$"));
        ((DbMapperManager)mapperManager).getDatabaseSetup().createTables();*/
        System.out.println("test");
    }
    
}
