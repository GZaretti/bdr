/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gza.transportPublic.idatasource;

import gza.transportPublic.idomain.IMecanicien;
import gza.transportPublic.idomain.IModel;

/**
 *
 * @author ZEED
 */
public interface IMecanicienMapper extends IMapper<IMecanicien>{
    
}
